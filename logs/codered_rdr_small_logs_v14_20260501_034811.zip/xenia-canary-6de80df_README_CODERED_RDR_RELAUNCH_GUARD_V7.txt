CodeRED Xenia RDR Multiplayer Relaunch Guard v7

Why this exists:
The screenshot shows RDR reached Xenia's "Title was restarted" path after entering a multiplayer mode. Xenia saved launch data, then the old termination path produced an access violation while JIT/game threads were still active.

What v7 changes:
1) Applies a tiny source patch to src\xenia\kernel\xam\xam_info.cc.
2) When XamLoaderLaunchTitle receives a valid launch path, it saves launch_data.bin and exits cleanly.
3) The v7 launcher waits for Xenia to exit, detects launch_data.bin, and restarts Xenia automatically so the saved launch data is consumed.

Install:
Extract this ZIP into:
D:\Games\Red Dead Redemption\xenia-canary-6de80df\

Use:
1) Run CodeRED_RDR_Multiplayer_RelaunchGuard_Menu_v7.bat
2) Choose 2 to apply the patch and rebuild.
3) Choose 3 to run Private Host Disc 2 with auto relaunch.

If it fails:
Choose 7 and send the generated CODERED_SEND_THESE_V7 folder or ZIP.
