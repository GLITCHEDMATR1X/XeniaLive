CodeRED Xenia RDR Easy Test Kit v3

Fixes the v2 path quoting issue that caused:
Exception calling "GetFullPath" ... Illegal characters in path.

Install:
1. Extract this zip over your xenia-canary-6de80df folder.
2. Allow overwrite.
3. Run CodeRED_Run_RDR_Local_OneClick_v3.bat.

Assumed game path:
D:\Games\Red Dead Redemption\

If xenia_canary.exe is missing, run:
CodeRED_Build_Xenia_Release_v3.bat

If it still fails, run:
CodeRED_Diagnose_RDR_Netplay_v3.bat

Send these files back:
logs\codered_easy_rdr_netplay.log
logs\codered_rdr_netplay_diagnose.txt
