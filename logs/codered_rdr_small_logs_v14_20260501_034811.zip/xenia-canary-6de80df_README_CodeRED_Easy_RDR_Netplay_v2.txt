CodeRED Xenia RDR Netplay Easy Test Kit v2
==========================================

Your RDR path is assumed to be:
D:\Games\Red Dead Redemption\

Run this first:
CodeRED_Run_RDR_Local_OneClick_v2.bat

What it does:
1. Updates all common Xenia/Canary config filenames:
   - xenia-canary.config.toml
   - xenia-canary-config.toml
   - xenia.config.toml
2. Preserves any existing config sections except [Netplay] and [CodeRED].
3. Starts tools\codered_rdr_private_host.py on port 36000.
4. Finds default.xex under D:\Games\Red Dead Redemption\.
5. Launches xenia_canary.exe with that default.xex.

If xenia_canary.exe is missing:
Run CodeRED_Build_Xenia_Release_v2.bat from a Visual Studio 2022 Developer PowerShell.

For local one-PC testing, this config is correct:
selected_network_interface = "127.0.0.1"
netplay_api_address = "http://127.0.0.1:36000/"

For two PCs:
- Start the private host on one PC.
- On both PCs, set netplay_api_address to http://HOST_PC_LAN_IP:36000/
- On each PC, set selected_network_interface to that PC's own LAN/VPN IPv4.

In Red Dead Redemption:
Single Player > Pause > Multiplayer > System Link > Free Roam

If it fails, run:
CodeRED_Diagnose_RDR_Netplay_v2.bat

Then send:
logs\codered_rdr_netplay_diagnose.txt
logs\codered_easy_rdr_netplay.log
Xenia log around the System Link / Free Roam attempt
