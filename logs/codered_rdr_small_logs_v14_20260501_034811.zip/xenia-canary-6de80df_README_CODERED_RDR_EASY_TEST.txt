CodeRED RDR Netplay Easy Test
=============================

Pre-filled RDR path:
D:\Games\Red Dead Redemption\

Run:
CodeRED_Easy_RDR_Netplay_Menu.bat

Fast local test:
CodeRED_OneClick_RDR_Test.bat

If xenia_canary.exe is missing, run:
CodeRED_Build_Xenia_Release.bat

Inside RDR:
Single Player > Pause > Multiplayer > System Link > Free Roam

Keep the private host window open while testing.
