CodeRED Xenia RDRMP World Salvage / Super v6 v8

Extract this into:
D:\Games\Red Dead Redemption\xenia-canary-6de80df\

Run:
CodeRED_RDRMP_World_Salvage_Menu_v8.bat

Use option 3 first:
Private WorldHost - Disc 2 - SAFE CPU

This does not turn PC RDRMP into an Xbox 360 server. It adds a world-aware private host and a manifest generated from RDRMP docs so later CodeRED/Xenia patches can consume sector/actor/weather metadata.

If you want to rebuild the manifest, place this zip beside the BAT:
xenia-rdrmp world salvage v6 base.zip
and use menu option 1.
