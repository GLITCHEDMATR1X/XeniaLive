CodeRED Xenia RDR Multiplayer Crash Guard v6

Extract this into:
D:\Games\Red Dead Redemption\xenia-canary-6de80df\

Run:
CodeRED_RDR_Multiplayer_CrashGuard_Menu_v6.bat

Recommended order:
1) Option 1: Private Host - Disc 2 - SAFE CPU
2) If it still crashes at multiplayer entry, run option 2: BARE test.
3) If it still crashes, run option 3: Offline Baseline.
4) Run option 7 and send back the generated ZIP or the CODERED_SEND_THESE_V6 folder.

What v6 changes:
- Waits for the private host to become healthy before launching.
- Forces Xenia log output into logs\xenia_codered_v6_*.log.
- Disables break_on_debugbreak and break_on_unimplemented_instructions for testing.
- Uses x64_extension_mask = 0 for the safest CPU/JIT path.
- Adds BARE mode that disables patches and title update for a clean crash comparison.
- Makes log collection produce both a ZIP and a plain folder to send if ZIP upload fails.
